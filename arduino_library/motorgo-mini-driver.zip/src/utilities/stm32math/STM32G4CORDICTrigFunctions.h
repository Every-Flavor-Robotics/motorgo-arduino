
#pragma once

#ifdef HAL_CORDIC_MODULE_ENABLED


bool SimpleFOC_CORDIC_Config(void);


#endif
