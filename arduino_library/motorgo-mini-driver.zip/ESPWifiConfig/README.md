# esp-wifi-config
A package to expose configurable variables as REST endpoints
