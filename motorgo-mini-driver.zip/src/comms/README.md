
# SimpleFOC communications support code

This folder contains classes to support you communicating between MCUs running SimpleFOC, and other systems.

